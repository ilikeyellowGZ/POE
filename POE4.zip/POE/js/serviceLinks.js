// Select each petOption element by its ID
const adoptDog = document.getElementById("adoptDog");
const adoptCat = document.getElementById("adoptCat");
const adoptMouse = document.getElementById("adoptMouse");
const adoptHorse = document.getElementById("adoptHorse");
const adoptRabbit = document.getElementById("adoptRabbit");
const adoptDegu = document.getElementById("adoptDegu");
const adoptRat = document.getElementById("adoptRat");
const adoptGuineaPig = document.getElementById("adoptGuineaPig");
const adoptHamster = document.getElementById("adoptHamster");
const adoptSnake = document.getElementById("adoptSnake");
const adoptChinchilla = document.getElementById("adoptChinchilla");
const adoptParrot = document.getElementById("adoptParrot");

// Add event listeners to each element
adoptDog.addEventListener("click", () => {
    window.open("https://www.bluecross.org.uk/rehome/dog", "_blank");
});

adoptCat.addEventListener("click", () => {
    window.open("https://www.bluecross.org.uk/rehome/cat", "_blank");
});

adoptMouse.addEventListener("click", () => {
    window.open("https://www.bluecross.org.uk/rehome/mouse", "_blank");
});

adoptHorse.addEventListener("click", () => {
    window.open("https://www.bluecross.org.uk/rehome/horse", "_blank");
});

adoptRabbit.addEventListener("click", () => {
    window.open("https://www.bluecross.org.uk/rehome/rabbit", "_blank");
});

adoptDegu.addEventListener("click", () => {
    window.open("https://www.bluecross.org.uk/rehome/degu", "_blank");
});

adoptRat.addEventListener("click", () => {
    window.open("https://www.bluecross.org.uk/rehome/rat", "_blank");
});

adoptGuineaPig.addEventListener("click", () => {
    window.open("https://www.bluecross.org.uk/rehome/guinea-pig", "_blank");
});

adoptHamster.addEventListener("click", () => {
    window.open("https://www.bluecross.org.uk/rehome/hamster", "_blank");
});

adoptSnake.addEventListener("click", () => {
    window.open("https://www.absoluteexoticssa.co.za/specialized-care/care-for-corn-snakes", "_blank");
});

adoptChinchilla.addEventListener("click", () => {
    window.open("https://www.bluecross.org.uk/rehome/gerbil", "_blank");
});

adoptParrot.addEventListener("click", () => {
    window.open("https://www.absoluteexoticssa.co.za/exotic-pets/blue-and-yellow-macaw", "_blank");
});


